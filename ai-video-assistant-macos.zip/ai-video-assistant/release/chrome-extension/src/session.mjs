import {LIMITS} from '../shared/contract.mjs';
export function createSession(sourceKey){return {sourceKey,messages:[],revision:0};}
export function appendTurn(session,question,answer){
  return {...session,revision:session.revision+1,messages:[...session.messages,{role:'user',text:question},{role:'assistant',text:answer}].slice(-LIMITS.history)};
}
export function selectSession(session,sourceKey){return session?.sourceKey===sourceKey?session:createSession(sourceKey);}
