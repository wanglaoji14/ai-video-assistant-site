export class NativeBridge {
  #port;#requests=new Map();
  constructor(host='com.aivideoassistant.workbuddy'){this.host=host;}
  #connect(){
    if(this.#port)return this.#port;
    const port=chrome.runtime.connectNative(this.host);this.#port=port;
    port.onMessage.addListener(event=>{
      const job=this.#requests.get(event.id);if(!job)return;
      if(['complete','status','error'].includes(event.type)){
        this.#requests.delete(event.id);clearTimeout(job.timer);
        event.type==='error'?job.reject(new Error(event.message||'连接器处理失败')):job.resolve(event);
      }else job.onEvent(event);
    });
    port.onDisconnect.addListener(()=>{
      this.#port=null;
      const missing=chrome.runtime.lastError?.message||'本机连接已断开';
      for(const job of this.#requests.values()){clearTimeout(job.timer);job.reject(new Error('本机连接器未就绪。请先安装连接器并登录 WorkBuddy。'+missing));}
      this.#requests.clear();
    });
    return port;
  }
  request(method,params,onEvent=()=>{},id=crypto.randomUUID()){
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{this.cancel(id);reject(new Error('连接超时，请重试'));},130000);
      this.#requests.set(id,{resolve,reject,timer,onEvent});
      try{this.#connect().postMessage({v:1,id,method,params});}catch(error){clearTimeout(timer);this.#requests.delete(id);reject(error);}
    });
  }
  cancel(id){
    this.#port?.postMessage({v:1,id,method:'cancel'});
    const job=this.#requests.get(id);
    if(job){clearTimeout(job.timer);job.reject(new Error('已取消'));this.#requests.delete(id);}
  }
  close(){this.#port?.disconnect();this.#port=null;}
}
