import {normalizeRect,publicPageURL} from '../shared/contract.mjs';

// Executed only after an explicit extension action, in an isolated content world.
export function inspectVideo() {
  const candidates=[...document.querySelectorAll('video')].map(video=>({video,rect:video.getBoundingClientRect()}))
    .filter(({rect})=>rect.width>=80&&rect.height>=45&&rect.bottom>0&&rect.right>0&&rect.left<innerWidth&&rect.top<innerHeight);
  candidates.sort((a,b)=>Number(b.video===document.pictureInPictureElement)-Number(a.video===document.pictureInPictureElement)||Number(!b.video.paused)-Number(!a.video.paused)||b.rect.width*b.rect.height-a.rect.width*a.rect.height);
  const selected=candidates[0];
  if(!selected)return {found:false,title:document.title};
  const {video,rect}=selected;
  const snippets=[];
  for(const track of video.textTracks){
    if(track.mode==='disabled')continue;
    try{for(const cue of track.cues||[]){if(cue.endTime>=video.currentTime-20&&cue.startTime<=video.currentTime+5)snippets.push(`[${Math.floor(cue.startTime)}s] ${cue.text}`);}}catch{}
  }
  // These are captions visible in the player, not the page's arbitrary body text.
  for(const selector of ['.ytp-caption-segment','.bpx-player-subtitle-panel-text','.bilibili-player-video-subtitle-panel-text']){
    for(const item of document.querySelectorAll(selector)){
      const r=item.getBoundingClientRect();
      if(r.width&&r.height&&r.bottom>rect.top&&r.top<rect.bottom)snippets.push(item.textContent||'');
    }
  }
  return {found:true,title:document.title,page:location.href,time:video.currentTime,
    paused:video.paused,duration:Number.isFinite(video.duration)?video.duration:null,
    captions:[...new Set(snippets)].join('\n').slice(0,12000),
    source:video.currentSrc||video.src||'',rect:{left:rect.left,top:rect.top,right:rect.right,bottom:rect.bottom},
    viewport:{width:innerWidth,height:innerHeight},imageKind:'visible-player'};
}

export async function collectContext(tabId) {
  const tab=await chrome.tabs.get(tabId);
  if(!tab?.url||!/^https?:/.test(tab.url))throw new Error('请在普通视频网页中点击插件图标');
  const [active]=await chrome.tabs.query({windowId:tab.windowId,active:true});
  if(active?.id!==tabId)throw new Error('请切回视频所在标签页后同步');
  const [inspection]=await chrome.scripting.executeScript({target:{tabId},func:inspectVideo});
  const info=inspection?.result;
  if(!info?.found)throw new Error('未找到可访问的播放器。请先显示视频；嵌入式或受保护的播放器可能不支持');
  const url=publicPageURL(info.page);
  // Capture locally first; only explicit question submission sends evidence to WorkBuddy.
  const shot=await chrome.tabs.captureVisibleTab(tab.windowId,{format:'jpeg',quality:85});
  const bitmap=await createImageBitmap(await (await fetch(shot)).blob());
  try{
    const rect=normalizeRect(info.rect,info.viewport,bitmap.width/info.viewport.width);
    const ratio=Math.min(1,1280/rect.width,900/rect.height);
    const canvas=new OffscreenCanvas(Math.max(1,Math.round(rect.width*ratio)),Math.max(1,Math.round(rect.height*ratio)));
    canvas.getContext('2d').drawImage(bitmap,rect.x,rect.y,rect.width,rect.height,0,0,canvas.width,canvas.height);
    const jpeg=await canvas.convertToBlob({type:'image/jpeg',quality:0.83});
    const bytes=new Uint8Array(await jpeg.arrayBuffer());
    let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
    const identity=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(url+'\n'+info.source.split('?')[0])));
    const sourceKey=[...identity].map(n=>n.toString(16).padStart(2,'0')).join('');
    return {title:info.title||new URL(url).hostname,url,time:info.time,sourceKey,
      image:'data:image/jpeg;base64,'+btoa(binary),imageKind:info.imageKind,captions:info.captions,transcript:'',paused:info.paused};
  }finally{bitmap.close();}
}
