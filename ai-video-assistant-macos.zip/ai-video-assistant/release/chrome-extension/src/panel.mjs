import {formatTime} from '../shared/contract.mjs';
const $=id=>document.getElementById(id),port=chrome.runtime.connect({name:'video-assistant-panel'});
let busy=false,context=null,pendingNode=null,currentQuestion='',stagedText='';
function error(message){$('failure').textContent=message;$('failure').hidden=false;}
function status(text){$('progress').textContent=text;$('progress').hidden=!text;}
function setBusy(value){busy=value;$('send').hidden=value;$('cancel').hidden=!value;$('question').disabled=value;$('refresh').disabled=value;$('clear').disabled=value;$('audio').disabled=value;}
function append(role,text){$('empty')?.remove();const n=document.createElement('div');n.className='turn '+role;n.textContent=text;$('conversation').append(n);$('conversation').scrollTop=$('conversation').scrollHeight;return n;}
function renderHistory(messages){$('conversation').replaceChildren();for(const m of messages)append(m.role,m.text);}
async function send(){
  const q=$('question').value.trim();if(!q||busy)return;
  const {sendConsent}=await chrome.storage.local.get('sendConsent');
  if(!sendConsent){$('consent').hidden=false;error('请先勾选数据发送授权，再发送问题');return;}
  $('failure').hidden=true;currentQuestion=q;setBusy(true);status('正在读取当前视频…');
  port.postMessage({type:'explain',question:q});
}
port.onMessage.addListener(event=>{
  if(event.type==='context'){
    context=event.context;$('title').textContent=context.title;
    $('meta').textContent=`${formatTime(context.time)} · 当前画面${context.captions?' + 字幕':''}${context.transcript?' + 语音转写':''}`;
    $('frame').src=context.image;$('frame').hidden=!context.image;
    renderHistory(event.messages||[]);
    if(!busy)status('');
  }
  if(event.type==='accepted'){append('user',event.question);pendingNode=append('assistant','');stagedText='';$('question').value='';}
  if(event.type==='delta'){stagedText+=event.text;if(pendingNode)pendingNode.textContent=stagedText;$('conversation').scrollTop=$('conversation').scrollHeight;}
  if(event.type==='progress')status(({capturing:'读取当前视频…',recording:'正在回放并采集这段声音…',transcribing:'正在本机识别语音…'})[event.stage]||'WorkBuddy 正在解释…');
  if(event.type==='transcribed'){if(context)context.transcript=event.transcript;$('meta').textContent=`${formatTime(event.time)} · 当前画面 + 语音转写`;setBusy(false);status('声音已识别，可以提问了');}
  if(event.type==='complete'){
    if(pendingNode)pendingNode.textContent=event.answer;else append('assistant',event.answer);
    const n=document.createElement('div');n.className='evidence';n.textContent=`${formatTime(event.time)} · 根据当前画面${context?.captions?'、字幕':''}${context?.transcript?'、语音转写':''}回答`;$('conversation').append(n);
    pendingNode=null;setBusy(false);status('');$('question').focus();$('conversation').scrollTop=$('conversation').scrollHeight;
  }
  if(event.type==='error'){pendingNode?.remove();pendingNode=null;setBusy(false);status('');error(event.message);if(!$('question').value)$('question').value=currentQuestion;}
  if(event.type==='status'){
    const ready=event.ready;$('connection').textContent=ready?'WorkBuddy 本机连接就绪':'需要安装本机连接器';$('backend-detail').textContent=ready?'本机引擎可用。实际调用需要 WorkBuddy 已登录且额度可用。':event.reason||'请先安装连接器并登录 WorkBuddy。';
  }
  if(event.type==='cleared'){renderHistory([]);status('');$('failure').hidden=true;}
});
port.onDisconnect.addListener(()=>{setBusy(false);error('扩展连接已断开，请关闭侧栏并重新打开');});
$('form').onsubmit=e=>{e.preventDefault();send();};
$('question').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send();}};
$('cancel').onclick=()=>{port.postMessage({type:'cancel'});status('正在停止…');};
$('refresh').onclick=()=>{setBusy(false);$('failure').hidden=true;port.postMessage({type:'capture'});};
$('clear').onclick=()=>port.postMessage({type:'clear'});
$('consent-check').onchange=async e=>{await chrome.storage.local.set({sendConsent:e.target.checked});if(e.target.checked){$('consent').hidden=true;$('failure').hidden=true;}};
$('help').onclick=()=>$('settings').showModal();$('close-settings').onclick=()=>$('settings').close();
$('revoke').onclick=async()=>{await chrome.storage.local.remove('sendConsent');$('consent-check').checked=false;$('consent').hidden=false;$('settings').close();};
$('audio').onclick=()=>$('speech').showModal();$('close-speech').onclick=()=>$('speech').close();
$('start-audio').onclick=()=>{$('speech').close();$('failure').hidden=true;setBusy(true);port.postMessage({type:'audio'});};
const {sendConsent}=await chrome.storage.local.get('sendConsent');$('consent').hidden=!!sendConsent;$('consent-check').checked=!!sendConsent;
port.postMessage({type:'status'});port.postMessage({type:'capture'});
