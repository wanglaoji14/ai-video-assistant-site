const message=async data=>{const r=await chrome.runtime.sendMessage({target:'audio-offscreen',...data});if(!r?.ok)throw new Error(r?.error||'无法采集声音');return r;};
export async function captureAudioClip(tabId,{signal}={}){
  if(!await chrome.offscreen.hasDocument())await chrome.offscreen.createDocument({url:'offscreen.html',reasons:['USER_MEDIA'],justification:'在用户明确选择后，采集当前视频短片段的标签页声音供本机语音识别'});
  const [r]=await chrome.scripting.executeScript({target:{tabId},func:()=>{
    const all=[...document.querySelectorAll('video')];const video=all.filter(v=>{const r=v.getBoundingClientRect();return r.width>80&&r.height>40;}).sort((a,b)=>b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight)[0];
    if(!video||!Number.isFinite(video.duration))return null;
    return {index:all.indexOf(video),time:video.currentTime,paused:video.paused||video.ended,rate:video.playbackRate,muted:video.muted,duration:video.duration,source:video.currentSrc};
  }});
  const original=r.result;if(!original)throw new Error('当前视频无法回放声音片段');
  const start=Math.max(0,original.time-15),seconds=original.time>0.5?original.time-start:Math.min(8,original.duration);
  let started=false;
  const abort=()=>{message({action:'cancel'}).catch(()=>{});};signal?.addEventListener('abort',abort,{once:true});
  try{
    if(signal?.aborted)throw new Error('已取消');
    const streamId=await chrome.tabCapture.getMediaStreamId({targetTabId:tabId});await message({action:'start',streamId});started=true;
    await chrome.scripting.executeScript({target:{tabId},func:async ({index,start,source})=>{const v=document.querySelectorAll('video')[index];if(!v||v.currentSrc!==source)throw new Error('视频已切换');v.currentTime=start;v.playbackRate=1;v.muted=false;await v.play();},args:[{index:original.index,start,source:original.source}]});
    await new Promise((resolve,reject)=>{const done=()=>{signal?.removeEventListener('abort',cancel);resolve();};const timer=setTimeout(done,Math.ceil(seconds*1000)+250);const cancel=()=>{clearTimeout(timer);reject(new Error('已取消'));};signal?.addEventListener('abort',cancel,{once:true});if(signal?.aborted)cancel();});
    const result=await message({action:'stop'});started=false;return {audio:result.audio,start,time:original.time};
  }finally{
    signal?.removeEventListener('abort',abort);if(started)await message({action:'cancel'}).catch(()=>{});
    await chrome.scripting.executeScript({target:{tabId},func:async o=>{const v=document.querySelectorAll('video')[o.index];if(!v||v.currentSrc!==o.source)return;v.pause();v.currentTime=o.time;v.playbackRate=o.rate;v.muted=o.muted;if(!o.paused)await v.play().catch(()=>{});},args:[original]}).catch(()=>{});
  }
}
