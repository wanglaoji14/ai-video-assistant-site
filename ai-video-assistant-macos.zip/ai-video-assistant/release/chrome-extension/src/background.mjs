import {collectContext} from './capture.mjs';
import {NativeBridge} from './bridge.mjs';
import {createSession,selectSession,appendTurn} from './session.mjs';
import {captureAudioClip} from './audio-capture.mjs';

const bridge=new NativeBridge(),sessions=new Map(),jobs=new Map(),audioJobs=new Map(),audioCache=new Map(),panels=new Set();
chrome.action.onClicked.addListener(tab=>{
  if(!tab.id)return;
  chrome.storage.session.set({activeSourceTab:tab.id});
  chrome.sidePanel.open({windowId:tab.windowId}).catch(()=>{});
});
chrome.tabs.onRemoved.addListener(tabId=>{audioJobs.get(tabId)?.abort();audioCache.delete(tabId);sessions.delete(tabId);if(jobs.has(tabId)){bridge.cancel(jobs.get(tabId));jobs.delete(tabId);}});
chrome.tabs.onUpdated.addListener((tabId,change)=>{if(change.status==='loading'){audioJobs.get(tabId)?.abort();audioCache.delete(tabId);sessions.delete(tabId);if(jobs.has(tabId)){bridge.cancel(jobs.get(tabId));jobs.delete(tabId);}}});
chrome.runtime.onConnect.addListener(port=>{
  if(port.name!=='video-assistant-panel'||port.sender?.id!==chrome.runtime.id)return;
  panels.add(port);
  const send=event=>{try{port.postMessage(event);}catch{}};
  let sourceTab=null;
  port.onMessage.addListener(async command=>{
    try{
      if(command.type==='cancel'){audioJobs.get(sourceTab)?.abort();if(sourceTab!==null&&jobs.has(sourceTab))bridge.cancel(jobs.get(sourceTab));return;}
      const stored=await chrome.storage.session.get('activeSourceTab');sourceTab=stored.activeSourceTab;
      if(command.type==='status'){
        const backend=await bridge.request('status');send({type:'status',...backend});return;
      }
      if(command.type==='audio'){
        if(!Number.isInteger(sourceTab)||jobs.has(sourceTab)||audioJobs.has(sourceTab))throw new Error('请先选择视频，并等待当前任务完成');
        const backend=await bridge.request('status');if(!backend.audio)throw new Error('本机语音组件未安装，请按安装指南启用语音');
        const controller=new AbortController(),tabId=sourceTab;audioJobs.set(tabId,controller);
        try{
          const context=await collectContext(tabId);send({type:'context',context,messages:sessions.get(tabId)?.messages||[]});
          send({type:'progress',stage:'recording'});const clip=await captureAudioClip(tabId,{signal:controller.signal});
          if(controller.signal.aborted)throw new Error('已取消');
          const id=crypto.randomUUID();jobs.set(tabId,id);
          const response=await bridge.request('transcribe',{audio:clip.audio,start:clip.start},send,id);
          audioCache.set(tabId,{sourceKey:context.sourceKey,time:clip.time,transcript:response.transcript});
          send({type:'transcribed',transcript:response.transcript,time:clip.time});
        }finally{audioJobs.delete(tabId);jobs.delete(tabId);}return;
      }
      if(command.type==='clear'){if(jobs.has(sourceTab))bridge.cancel(jobs.get(sourceTab));sessions.delete(sourceTab);audioCache.delete(sourceTab);send({type:'cleared'});return;}
      if(!['capture','explain'].includes(command.type))throw new Error('未知操作');
      if(!Number.isInteger(sourceTab))throw new Error('请先在视频页面点击插件图标');
      if(command.type==='explain'&&jobs.has(sourceTab))throw new Error('正在处理上一条问题');
      send({type:'progress',stage:'capturing'});
      const context=await collectContext(sourceTab);
      const speech=audioCache.get(sourceTab);if(speech?.sourceKey===context.sourceKey)context.transcript=speech.transcript;
      let session=selectSession(sessions.get(sourceTab),context.sourceKey);sessions.set(sourceTab,session);
      send({type:'context',context,messages:session.messages});
      if(command.type==='capture')return;
      const consent=await chrome.storage.local.get('sendConsent');
      if(!consent.sendConsent)throw new Error('请先确认允许将本次视频画面与问题发送给 WorkBuddy');
      const question=String(command.question||'').trim();if(!question||question.length>6000)throw new Error('问题为空或超过 6000 字');
      const requestId=crypto.randomUUID(),tabId=sourceTab;jobs.set(tabId,requestId);
      send({type:'accepted',question,requestId});
      try{
        const response=await bridge.request('explain',{question,context,history:session.messages},send,requestId);
        // A navigation or source switch must never attach an old answer to a new video.
        if(jobs.get(tabId)!==requestId||sessions.get(tabId)?.sourceKey!==context.sourceKey)return;
        session=appendTurn(session,question,response.answer);sessions.set(tabId,session);
        send({type:'complete',answer:response.answer,usage:response.usage,time:context.time});
      }finally{if(jobs.get(tabId)===requestId)jobs.delete(tabId);}
    }catch(error){send({type:'error',message:error.message});}
  });
  port.onDisconnect.addListener(()=>{panels.delete(port);if(sourceTab!==null){audioJobs.get(sourceTab)?.abort();if(jobs.has(sourceTab))bridge.cancel(jobs.get(sourceTab));sessions.delete(sourceTab);audioCache.delete(sourceTab);}if(!panels.size)bridge.close();});
});
