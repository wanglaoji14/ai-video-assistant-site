let stream=null,recorder=null,audioContext=null,chunks=[],bytes=0;
function cleanup(){stream?.getTracks().forEach(t=>t.stop());stream=null;audioContext?.close();audioContext=null;recorder=null;}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
 if(m.target!=='audio-offscreen'||sender.id!==chrome.runtime.id)return false;
 (async()=>{
  if(m.action==='start'){
   if(recorder)throw new Error('已有声音片段正在录制');
   stream=await navigator.mediaDevices.getUserMedia({audio:{mandatory:{chromeMediaSource:'tab',chromeMediaSourceId:m.streamId}},video:false});
   audioContext=new AudioContext();audioContext.createMediaStreamSource(stream).connect(audioContext.destination);
   chunks=[];bytes=0;recorder=new MediaRecorder(stream,{mimeType:'audio/webm;codecs=opus',audioBitsPerSecond:64000});
   recorder.ondataavailable=e=>{bytes+=e.data.size;if(bytes<3000000)chunks.push(e.data);};recorder.start(250);return {ok:true};
  }
  if(m.action==='cancel'){if(recorder&&recorder.state!=='inactive')recorder.stop();cleanup();chunks=[];return {ok:true};}
  if(m.action==='stop'){
   if(!recorder)throw new Error('录制已结束');
   const blob=await new Promise(resolve=>{recorder.onstop=()=>resolve(new Blob(chunks,{type:'audio/webm'}));recorder.stop();});
   cleanup();if(bytes>=3000000)throw new Error('声音片段超过限制');
   const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(new Error('声音编码失败'));r.readAsDataURL(blob);});return {ok:true,audio:data};
  }
  throw new Error('未知采集操作');
 })().then(reply).catch(error=>{cleanup();reply({ok:false,error:error.message});});return true;
});
