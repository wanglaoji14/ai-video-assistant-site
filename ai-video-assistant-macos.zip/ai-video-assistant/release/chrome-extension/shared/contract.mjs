export const VERSION = 1;
export const LIMITS = Object.freeze({message: 8 * 1024 * 1024, question: 6000, history: 12, text: 12000, image: 5 * 1024 * 1024, output: 40000});
export class ContractError extends Error {constructor(message) {super(message); this.name = 'ContractError';}}
const object = value => value && typeof value === 'object' && !Array.isArray(value);
const text = (value, max, name) => {if(typeof value !== 'string' || value.length > max) throw new ContractError(`${name}格式不正确或过长`);return value;};
export function validateRequest(value) {
  if (!object(value) || value.v !== VERSION || typeof value.id !== 'string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(value.id)) throw new ContractError('请求标识无效');
  if (!['status','explain','cancel','transcribe'].includes(value.method)) throw new ContractError('不支持的请求');
  if(value.method==='transcribe'){
    const p=value.params;
    if(!object(p)||typeof p.audio!=='string'||p.audio.length>LIMITS.image||!/^data:audio\/webm(?:;codecs=opus)?;base64,[A-Za-z0-9+/]+=*$/.test(p.audio))throw new ContractError('声音片段格式或大小无效');
    if(!Number.isFinite(p.start)||p.start<0)throw new ContractError('片段起始时间无效');
    return {v:VERSION,id:value.id,method:value.method,params:{audio:p.audio,start:p.start}};
  }
  if (value.method !== 'explain') return {v: VERSION, id: value.id, method: value.method};
  const p=value.params;
  if (!object(p) || !object(p.context)) throw new ContractError('视频上下文无效');
  const question=text(p.question,LIMITS.question,'问题').trim();
  if (!question) throw new ContractError('请输入问题');
  const c=p.context;
  const time=c.time===null?null:c.time;
  if (time!==null && (!Number.isFinite(time)||time<0)) throw new ContractError('视频时间无效');
  const image=text(c.image||'',LIMITS.image,'画面');
  if (image && !/^data:image\/jpeg;base64,[A-Za-z0-9+/]+=*$/.test(image)) throw new ContractError('画面编码无效');
  const context={title:text(c.title||'',1000,'标题'),url:publicPageURL(c.url),time,image,
    captions:text(c.captions||'',LIMITS.text,'字幕'),sourceKey:text(c.sourceKey||'',3000,'视频标识'),
    imageKind:['video-frame','visible-player'].includes(c.imageKind)?c.imageKind:'none',
    transcript:text(c.transcript||'',LIMITS.text,'语音转写')};
  if(!image&&!context.captions&&!context.transcript) throw new ContractError('没有可用的视频依据，请同步视频内容');
  const history=Array.isArray(p.history)?p.history.slice(-LIMITS.history).map(h=>{
    if(!object(h)||!['user','assistant'].includes(h.role)) throw new ContractError('对话格式无效');
    return {role:h.role,text:text(h.text,LIMITS.text,'对话')};
  }):[];
  return {v:VERSION,id:value.id,method:'explain',params:{question,context,history}};
}
export function publicPageURL(value) {
  let url; try{url=new URL(value);}catch{throw new ContractError('视频页面地址无效');}
  if(!['https:','http:'].includes(url.protocol)||url.username||url.password) throw new ContractError('仅支持普通网页视频');
  const selected=new URL(url.origin+url.pathname);
  if(['youtube.com','www.youtube.com','m.youtube.com'].includes(url.hostname)&&url.searchParams.has('v')) selected.searchParams.set('v',url.searchParams.get('v'));
  return selected.href;
}
export function formatTime(seconds) {
  if(!Number.isFinite(seconds)) return '时间未知';
  const n=Math.max(0,Math.floor(seconds));
  return (n>=3600?`${Math.floor(n/3600)}:`:'')+`${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
}
export function normalizeRect(rect, viewport, scale=1) {
  const x=Math.max(0,rect.left), y=Math.max(0,rect.top);
  const width=Math.max(0,Math.min(rect.right,viewport.width)-x),height=Math.max(0,Math.min(rect.bottom,viewport.height)-y);
  if(width<40||height<30) throw new ContractError('播放器不在可见区域，请将视频滚动到屏幕内');
  return {x:Math.round(x*scale),y:Math.round(y*scale),width:Math.round(width*scale),height:Math.round(height*scale)};
}
