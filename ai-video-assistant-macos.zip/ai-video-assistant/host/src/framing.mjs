import {LIMITS} from '../../shared/contract.mjs';
export class NativeDecoder {
  #buffer=Buffer.alloc(0);
  push(chunk) {
    this.#buffer=Buffer.concat([this.#buffer,chunk]);
    const messages=[];
    while(this.#buffer.length>=4){
      const length=this.#buffer.readUInt32LE(0);
      if(length<2||length>LIMITS.message) throw new Error('原生消息长度超出限制');
      if(this.#buffer.length<length+4)break;
      const raw=this.#buffer.subarray(4,length+4);this.#buffer=this.#buffer.subarray(length+4);
      messages.push(JSON.parse(raw.toString('utf8')));
    }
    return messages;
  }
  finish(){if(this.#buffer.length)throw new Error('原生消息被截断');}
}
export function encodeNative(value){
  const data=Buffer.from(JSON.stringify(value));
  if(data.length>1024*1024)throw new Error('返回数据超出浏览器限制');
  const header=Buffer.alloc(4);header.writeUInt32LE(data.length);return Buffer.concat([header,data]);
}
