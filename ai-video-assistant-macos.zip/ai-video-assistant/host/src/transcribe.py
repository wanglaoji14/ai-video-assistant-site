"""Local-only speech recognition. Model cache must be provisioned explicitly."""
import json
import sys
from faster_whisper import WhisperModel

audio_path, cache, offset = sys.argv[1], sys.argv[2], float(sys.argv[3])
model = WhisperModel('base', device='cpu', compute_type='int8', download_root=cache, local_files_only=True)
segments, info = model.transcribe(audio_path, beam_size=3, vad_filter=True, condition_on_previous_text=False)
result = [{'start': round(s.start+offset,2), 'end': round(s.end+offset,2), 'text': s.text.strip()} for s in segments if s.text.strip()]
print(json.dumps({'segments': result, 'language': info.language}, ensure_ascii=False))
