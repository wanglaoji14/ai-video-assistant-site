import {spawn} from 'node:child_process';
import {access} from 'node:fs/promises';
import {SYSTEM_PROMPT,modelInput} from './prompt.mjs';
import {LIMITS} from '../../shared/contract.mjs';

export class WorkBuddyAdapter {
  constructor({node=process.execPath,cli,workspace,timeout=120000,spawnProcess=spawn}){Object.assign(this,{node,cli,workspace,timeout,spawnProcess});}
  async status(){try{await access(this.cli);return {ready:true,backend:'WorkBuddy 本机引擎',audio:false};}catch{return {ready:false,reason:'未找到 WorkBuddy，请安装桌面客户端并登录'};}}
  explain(params,{signal,onEvent=()=>{}}={}){
    return new Promise((resolve,reject)=>{
      if(signal?.aborted)return reject(new Error('已取消'));
      const args=[this.cli,'-p','--input-format','stream-json','--output-format','stream-json','--include-partial-messages',
        '--tools','','--strict-mcp-config','--mcp-config','{"mcpServers":{}}',
        '--no-session-persistence','--max-turns','1','--effort','low','--system-prompt',SYSTEM_PROMPT];
      const child=this.spawnProcess(this.node,args,{cwd:this.workspace,stdio:['pipe','pipe','pipe'],shell:false,env:{...process.env,NO_COLOR:'1'}});
      let settled=false,buffer='',lastText='',stderrSize=0;
      const settle=(error,result)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);child.kill('SIGTERM');
        const killer=setTimeout(()=>{if(child.exitCode===null)child.kill('SIGKILL');},1500);killer.unref();error?reject(error):resolve(result);};
      const abort=()=>settle(new Error('已取消'));
      const timer=setTimeout(()=>settle(new Error('WorkBuddy 响应超时，请缩小问题范围后重试')),this.timeout);
      signal?.addEventListener('abort',abort,{once:true});
      child.on('error',()=>settle(new Error('无法启动 WorkBuddy 本机引擎')));
      child.stderr.on('data',chunk=>{stderrSize+=chunk.length;if(stderrSize>2*1024*1024)settle(new Error('引擎异常输出过多，请检查 WorkBuddy 登录状态'));});
      child.stdout.setEncoding('utf8');
      child.stdout.on('data',chunk=>{
        buffer+=chunk;
        if(Buffer.byteLength(buffer)>12*1024*1024)return settle(new Error('引擎响应超过限制'));
        let newline;
        while((newline=buffer.indexOf('\n'))!==-1){
          const line=buffer.slice(0,newline);buffer=buffer.slice(newline+1);
          let event;try{event=JSON.parse(line);}catch{continue;}
          if(event.type==='stream_event'&&event.event?.type==='content_block_delta'&&event.event.delta?.type==='text_delta'){
            const text=event.event.delta.text||'';
            if(lastText.length+text.length<=LIMITS.output){lastText+=text;onEvent({type:'delta',text});}
          }
          if(event.type==='result'){
            if(event.is_error||event.subtype==='error')return settle(new Error('WorkBuddy 未能完成请求，请确认账号已登录且额度可用'));
            const answer=typeof event.result==='string'?event.result:lastText;
            if(!answer.trim())return settle(new Error('模型未返回可用解释'));
            if(answer.length>LIMITS.output)return settle(new Error('回答过长，请缩小问题范围'));
            return settle(null,{answer,usage:event.usage||null});
          }
        }
      });
      child.on('close',()=>{if(!settled)settle(new Error('WorkBuddy 提前结束，请检查登录状态后重试'));});
      child.stdin.on('error',()=>{});
      child.stdin.end(JSON.stringify(modelInput(params))+'\n');
    });
  }
}
