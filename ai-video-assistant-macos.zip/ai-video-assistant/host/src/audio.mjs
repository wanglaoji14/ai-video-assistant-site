import {spawn} from 'node:child_process';import {mkdtemp,writeFile,rm,access} from 'node:fs/promises';import {join,dirname} from 'node:path';import {tmpdir} from 'node:os';import {fileURLToPath} from 'node:url';
export async function audioReady(config){if(!config?.python)return false;try{await access(config.python);await access(config.models);return true;}catch{return false;}}
export async function transcribeAudio(params,config,{signal}={}){
  if(!await audioReady(config))throw new Error('请先安装本机语音组件，参见安装指南的“启用语音”');
  const folder=await mkdtemp(join(tmpdir(),'aiva-audio-'));
  try{
    const input=join(folder,'clip.webm');await writeFile(input,Buffer.from(params.audio.split(',')[1],'base64'),{mode:0o600});
    return await new Promise((resolve,reject)=>{
      const child=spawn(config.python,[join(dirname(fileURLToPath(import.meta.url)),'transcribe.py'),input,config.models,String(params.start)],{stdio:['ignore','pipe','ignore'],shell:false,env:{...process.env,HF_HUB_OFFLINE:'1',HF_HUB_DISABLE_TELEMETRY:'1'}});
      let output='',settled=false;
      const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);if(child.exitCode===null){child.kill('SIGTERM');const timer=setTimeout(()=>child.kill('SIGKILL'),1000);timer.unref();}error?reject(error):resolve(value);};
      const abort=()=>finish(new Error('已取消语音识别'));
      const timer=setTimeout(()=>finish(new Error('本机语音识别超时，请缩短片段')),90000);
      signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
      child.on('error',()=>finish(new Error('无法启动本机语音组件')));
      child.stdout.setEncoding('utf8');child.stdout.on('data',data=>{output+=data;if(output.length>100000)finish(new Error('识别结果超过限制'));});
      child.on('close',code=>{if(settled)return;if(code!==0)return finish(new Error('本机语音识别失败，请重新安装语音组件'));let value;try{value=JSON.parse(output.trim().split('\n').at(-1));}catch{return finish(new Error('无法读取语音识别结果'));}
        const transcript=(value.segments||[]).map(s=>`[${s.start}s–${s.end}s] ${s.text}`).join('\n').slice(0,12000);
        if(!transcript)return finish(new Error('片段中未检测到可识别的语音'));finish(null,{transcript,language:value.language});
      });
    });
  }finally{await rm(folder,{recursive:true,force:true});}
}
