import {readFile,mkdir} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {NativeDecoder,encodeNative} from './framing.mjs';
import {validateRequest,VERSION} from '../../shared/contract.mjs';
import {WorkBuddyAdapter} from './workbuddy.mjs';
import {audioReady,transcribeAudio} from './audio.mjs';

const root=dirname(dirname(dirname(fileURLToPath(import.meta.url))));
const config=JSON.parse(await readFile(join(root,'host-config.json'),'utf8'));
const origin=process.argv[2];
if(!config.origins.includes(origin)){process.stderr.write('Native host origin denied\n');process.exit(1);}
await mkdir(config.workspace,{recursive:true,mode:0o700});
const adapter=new WorkBuddyAdapter({node:config.node,cli:config.cli,workspace:config.workspace});
const decoder=new NativeDecoder(),controllers=new Map();
const reply=value=>{if(!process.stdout.destroyed)process.stdout.write(encodeNative({v:VERSION,...value}));};
process.stdin.on('data',chunk=>{
  let values;try{values=decoder.push(chunk);}catch{process.stderr.write('Invalid native message\n');process.exitCode=1;process.stdin.destroy();return;}
  for(const raw of values)handle(raw);
});
async function handle(raw){
  let request;
  try{
    request=validateRequest(raw);
    if(request.method==='cancel'){controllers.get(request.id)?.abort();return;}
    if(request.method==='status'){reply({id:request.id,type:'status',...(await adapter.status()),audio:await audioReady(config.audio)});return;}
    if(controllers.has(request.id))throw new Error('重复的请求');
    if(controllers.size>=2)throw new Error('已有请求在处理，请等待或取消');
    const controller=new AbortController();controllers.set(request.id,controller);
    if(request.method==='transcribe'){
      reply({id:request.id,type:'progress',stage:'transcribing'});
      const result=await transcribeAudio(request.params,config.audio,{signal:controller.signal});reply({id:request.id,type:'complete',...result});return;
    }
    reply({id:request.id,type:'progress',stage:'explaining'});
    const result=await adapter.explain(request.params,{signal:controller.signal,onEvent:event=>reply({id:request.id,...event})});
    reply({id:request.id,type:'complete',...result});
  }catch(error){reply({id:request?.id||'invalid',type:'error',message:error.message});}
  finally{if(['explain','transcribe'].includes(request?.method))controllers.delete(request.id);}
}
function stop(){for(const c of controllers.values())c.abort();}
process.stdin.on('end',stop);process.on('SIGTERM',()=>{stop();process.exit(0);});
process.stdout.on('error',stop);
