#!/bin/sh
set -eu
TASK_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TASK_NODE=''
for candidate in /opt/homebrew/bin/node /usr/local/bin/node; do
  if [ -x "$candidate" ] && "$candidate" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)' 2>/dev/null; then
    TASK_NODE=$candidate
    break
  fi
done
if [ -z "$TASK_NODE" ]; then
  TASK_ARCHIVE='/Applications/WorkBuddy.app/Contents/Resources/vendor/node.tar.gz'
  TASK_RUNTIME="$HOME/Library/Application Support/AI Video Assistant/node-runtime"
  if [ ! -f "$TASK_ARCHIVE" ]; then
    echo '请先安装 WorkBuddy，或安装 Node.js 22 及以上版本。'
    exit 1
  fi
  mkdir -p "$TASK_RUNTIME"
  tar -xzf "$TASK_ARCHIVE" -C "$TASK_RUNTIME"
  TASK_NODE=$(find "$TASK_RUNTIME" -type f -path '*/bin/node' -print -quit)
fi
cd "$TASK_ROOT"
"$TASK_NODE" scripts/install-host.mjs
echo '安装完成。现在可以打开 Chrome 中的 AI 视频助手。'
