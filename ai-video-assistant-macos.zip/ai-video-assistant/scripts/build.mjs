import {mkdir,readFile,writeFile,cp,readdir,stat} from 'node:fs/promises';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,generateKeyPairSync} from 'node:crypto';
const root=dirname(dirname(fileURLToPath(import.meta.url))),out=join(root,'release/chrome-extension');
await mkdir(out,{recursive:true});await mkdir(join(root,'.runtime'),{recursive:true});
let key;
try{key=await readFile(join(root,'scripts/extension-public-key.txt'),'utf8');}catch{
  key=generateKeyPairSync('rsa',{modulusLength:2048}).publicKey.export({type:'spki',format:'der'}).toString('base64');
  await writeFile(join(root,'.runtime/extension-public-key.txt'),key);
}
const extensionId=[...createHash('sha256').update(Buffer.from(key,'base64')).digest('hex').slice(0,32)].map(c=>String.fromCharCode(97+parseInt(c,16))).join('');
await cp(join(root,'extension'),out,{recursive:true});await cp(join(root,'shared'),join(out,'shared'),{recursive:true});
const website='https://wanglaoji14.github.io/ai-video-assistant-site/';
await writeFile(join(out,'privacy.html'),(await readFile(join(root,'site/dist/privacy.html'),'utf8')).replaceAll('href="./"',`href="${website}"`).replaceAll('href="install.html"',`href="${website}install.html"`));
for(const name of await readdir(join(out,'src'))){if(name.endsWith('.mjs')){const p=join(out,'src',name);await writeFile(p,(await readFile(p,'utf8')).replaceAll('../../shared/','../shared/'));}}
const manifest={manifest_version:3,name:'AI 视频助手',version:'1.0.0',description:'暂停视频，在右侧栏直接提问。结合当前画面和可用字幕，由 WorkBuddy 解释。需安装本机连接器。',
minimum_chrome_version:'116',key,homepage_url:website,permissions:['activeTab','scripting','sidePanel','nativeMessaging','storage','tabCapture','offscreen'],
action:{default_title:'询问当前视频',default_icon:{16:'assets/icon16.png',32:'assets/icon32.png',48:'assets/icon48.png',128:'assets/icon128.png'}},
icons:{16:'assets/icon16.png',32:'assets/icon32.png',48:'assets/icon48.png',128:'assets/icon128.png'},
background:{service_worker:'src/background.mjs',type:'module'},side_panel:{default_path:'panel.html'},
content_security_policy:{extension_pages:"script-src 'self'; object-src 'none'; base-uri 'none'"}};
await writeFile(join(out,'manifest.json'),JSON.stringify(manifest,null,2));
await writeFile(join(root,'release/extension-identity.json'),JSON.stringify({extensionId,version:manifest.version},null,2));
console.log(JSON.stringify({extensionId,output:out}));
