import {mkdtemp,mkdir,cp,readFile,writeFile,rm} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=dirname(dirname(fileURLToPath(import.meta.url))),temp=await mkdtemp(join(tmpdir(),'ai-video-release-'));
try{
  const app=join(temp,'ai-video-assistant');await mkdir(app);
  for(const p of ['host','shared','scripts','package.json','README.md','安装本机连接器.command','release/chrome-extension','release/extension-identity.json'])await cp(join(root,p),join(app,p),{recursive:true});
  await mkdir(join(root,'site/dist/downloads'),{recursive:true});
  const destination=join(root,'site/dist/downloads/ai-video-assistant-macos.zip');await rm(destination,{force:true});
  execFileSync('/usr/bin/zip',['-qr',destination,'ai-video-assistant'],{cwd:temp});
  const store=join(temp,'store');await cp(join(root,'release/chrome-extension'),store,{recursive:true});
  const manifest=JSON.parse(await readFile(join(store,'manifest.json'),'utf8'));delete manifest.key;await writeFile(join(store,'manifest.json'),JSON.stringify(manifest,null,2));
  const storeZip=join(root,'release/chrome-web-store.zip');await rm(storeZip,{force:true});execFileSync('/usr/bin/zip',['-qr',storeZip,'.'],{cwd:store});
  console.log('Packaged store upload and public macOS installer without local configuration or credentials.');
}finally{await rm(temp,{recursive:true,force:true});}
