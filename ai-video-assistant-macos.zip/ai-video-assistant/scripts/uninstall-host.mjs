import {readFile,rm} from 'node:fs/promises';import {homedir} from 'node:os';import {join} from 'node:path';
const destination=join(homedir(),'Library/Application Support/AI Video Assistant');
const registry=join(homedir(),'Library/Application Support/Google/Chrome/NativeMessagingHosts/com.aivideoassistant.workbuddy.json');
try{const config=JSON.parse(await readFile(registry,'utf8'));if(config.name!=='com.aivideoassistant.workbuddy'||!config.path.startsWith(destination+'/'))throw new Error('连接器路径与本产品不符，未删除');await rm(registry);}catch(e){if(e.code!=='ENOENT')throw e;}
await rm(destination,{recursive:true,force:true});console.log('已移除 AI 视频助手本机连接器。WorkBuddy 本身未被修改。');
