# 停一下 · 视频解惑

通用视频解释的 Chrome 右侧栏。用户暂停、提问，使用当前视频画面和可用字幕生成解释。插件免费，模型消耗按用户自己的 WorkBuddy 权益计算。

这是从空目录编写的实现，不导入先前 Demo 的任何代码或素材。

## 要求

- macOS、Chrome 116 或更高版本。
- Node.js 22 或更高版本。
- 已安装并登录 WorkBuddy；首批集成针对客户端 5.3.14 内置 CLI 验证。

## 构建与验证

```sh
npm test
npm run build
npm run install:host
```

在 Chrome 开发者模式加载 `release/chrome-extension`，在视频网页点击插件图标。

Native Messaging Host 单独安装到用户的 Application Support 目录。它只接受当前扩展来源，使用参数数组启动官方安装包中的 CLI，并关闭模型的工具权限。不读取、复制或分发 WorkBuddy 凭据。

## 模块

- `extension/src/capture.mjs`：播放器选择、可见区域裁切与字幕采集。
- `extension/src/background.mjs`：侧栏事件、来源隔离和请求生命周期。
- `extension/src/bridge.mjs`：原生消息通道、超时与取消。
- `host/src/`：分片消息解码、请求校验、模型协议适配。
- `shared/contract.mjs`：边界验证和容量限制。
- `tests/`：协议、隐私边界、取消、超时与上下文隔离验证。
- `site/`：产品说明、安装指南与隐私政策。

## 可选语音组件

运行 `node scripts/install-audio.mjs /path/to/python3.12` 安装本机 Faster Whisper 组件及 base 模型。仅在用户确认后回放并采集短片段，离线转写，不使用麦克风或第三方转写 API。

## 尚未开放的能力

自动替代来源查找、Windows 连接器和 WorkBuddy 云端商业专家尚未实现，不能宣传为已支持。受保护或不可访问的播放器可能无法采集。

正式发布需要分别确认 Chrome 商店审核、安装包下载与本机连接器安装体验。上传为草稿不等于公开上线。
